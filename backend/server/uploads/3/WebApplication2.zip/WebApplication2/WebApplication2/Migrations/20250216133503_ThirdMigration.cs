﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication2.Migrations
{
    /// <inheritdoc />
    public partial class ThirdMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Groupes",
                newName: "Specialite");

            migrationBuilder.AddColumn<int>(
                name: "Niveau",
                table: "Groupes",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Niveau",
                table: "Groupes");

            migrationBuilder.RenameColumn(
                name: "Specialite",
                table: "Groupes",
                newName: "Name");
        }
    }
}
