﻿namespace WebApplication2.Models
{
    public class Groupe
    {
        public Groupe()
        {
            Id = 0;
            Niveau = 0;
            Specialite = "";
            Students = new List<Student>();
        }
        public Groupe(int id, int niveau, string specialite, List<Student> students)
        {
            Id = id;
            Niveau = niveau;
            Specialite = specialite;
            Students = students;
        }

        public int Id { get; set; }

        public int Niveau { get; set; }
        public string Specialite { get; set; }

        public List<Student> Students { get; set; }

    }
}
