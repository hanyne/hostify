﻿namespace WebApplication2.Models
{
    public class Student
   
    {
        public Student()
        {
            Id = 0;
            Name = "";
            Email = "";
            Address = "";
            Age = 0;
            GroupeId = 0;
           

        }

        public Student(int id, string name, string email, string address, int age, int groupeId, Groupe groupe)
        {
            Id = id;
            Name = name;
            Email = email;
            Address = address;
            Age = age;
            GroupeId = groupeId;
            Groupe = groupe;
        }
        public int Id { get; set; }
        public  string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public int GroupeId { get; set; }
        public virtual Groupe Groupe { get; set; }
    }
}
